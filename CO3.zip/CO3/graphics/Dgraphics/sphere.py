def sphere(x):
    a=4*(3.14)*x*x*x
    p=6.2832*x
    print("Perimeter of sphere:",p)
    print("Area of sphere:",a)
r=int(input("Enter the radius of the sphere:"))
sphere(r)
    
