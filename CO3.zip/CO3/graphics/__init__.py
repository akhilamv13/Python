import graphics.Dgraphics
from graphics.rectangle import rectangle
from graphics.circle import circle
