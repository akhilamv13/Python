def circle(x):
    a=(3.14)*x*x
    p=2*(3.14)*x
    print("Area of circle:",p)
    print("Area of circle:",a)
r=int(input("Enter the radius of the circle:"))
circle(r)
